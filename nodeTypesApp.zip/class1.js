"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var clas1 = /** @class */ (function () {
    function clas1() {
    }
    clas1.prototype.sayHello = function (aName) {
        console.log(aName);
    };
    clas1.prototype.saludar = function () {
        this.sayHello('Hola mundo !!!');
    };
    return clas1;
}());
exports.clas1 = clas1;
//# sourceMappingURL=class1.js.map