﻿export class clas1 {

  

  constructor() {
  }

  sayHello(aName: string) {

    console.log(aName);
  }

  saludar() {

    this.sayHello('Hola mundo !!!');
  }
}